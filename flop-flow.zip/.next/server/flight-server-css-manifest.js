self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\app\\page.js": [
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\node_modules\\reactflow\\dist\\base.css"
    ],
    "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\app\\layout.js": [
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\app\\globals.css"
    ]
  },
  "cssModules": {
    "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\app\\page": [
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\app\\globals.css",
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\node_modules\\reactflow\\dist\\base.css"
    ],
    "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\app\\chatBot\\page": [
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\app\\globals.css",
      "A:\\_AK\\_Main\\Task\\React-flow\\Chatbot-flow-builder\\Chatbot-flow-builder\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  }
}